module.exports = {
  globDirectory: 'public/',
  globPatterns: ['**/*.{png,ico}'],
  swDest: 'public/sw.js',
};
